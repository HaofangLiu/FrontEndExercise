function sayHello(name) {
  console.log('Hi ' + name);
}

sayHello();