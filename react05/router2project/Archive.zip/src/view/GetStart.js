import React from "react";

function GetStart(props) {
    // console.log(props)
  return <div>GetStart</div>;
}

export default GetStart;
