import React from "react";

function AboutPage(props) {
    // console.log(props)
  return <div>about page</div>;
}

export default AboutPage;
